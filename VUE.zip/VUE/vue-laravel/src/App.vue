<script setup>
import DashboardData from './components/DashboardData.vue'
</script>

<template>
  <div>
    <header>
      <img alt="Vue logo" class="logo" src="@/assets/logo.svg" width="125" height="125" />

      <div class="wrapper">
        <dashboard-data></dashboard-data>
      </div>
    </header>
  </div>
</template>

<style scoped>
/* Здесь стили */
</style>
